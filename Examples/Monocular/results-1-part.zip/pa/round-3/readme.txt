skip-n means skipping n initial frames before feeding into VO pipeline

skip-3500 was used for Hybrid-VO experiments in seqSlamUtils.ipynb after pose conversion using poseConvert.cpp from opencv-general-codes/testOpencv/src/
